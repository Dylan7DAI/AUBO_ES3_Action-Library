from __future__ import annotations

import json
import unittest

from pydantic import ValidationError

from scripts.llm_primitive_preview import (
    ChoreographyPlan,
    expected_transition_type,
    format_plan_json,
    normalize_result,
    validate_plan_for_result,
)


def sample_plan(
    primitive: str = "rise",
    valence: float = 0.50,
    emotion_name: str = "joy",
    transition_type: str = "continuation",
) -> dict:
    return {
        "emotion_state": {
            "emotion_name": emotion_name,
            "valence": valence,
            "arousal": 0.60,
            "intensity": 0.50,
            "persistence": 0.40,
            "unexpectedness": 0.20,
        },
        "transition_type": transition_type,
        "brief_reason": "本轮结果与跨回合历史一致",
        "global_tempo": 1.00,
        "steps": [
            {
                "primitive": primitive,
                "amplitude_scale": 0.80,
                "speed_scale": 1.00,
                "repeat": 1,
            }
        ],
    }


class PrimitivePreviewTests(unittest.TestCase):
    def test_terminal_input_uses_prompt_terms(self) -> None:
        self.assertEqual(normalize_result("t"), "correct")
        self.assertEqual(normalize_result("F"), "incorrect")
        self.assertIsNone(normalize_result("wrong"))

    def test_correct_accepts_positive_family(self) -> None:
        plan = ChoreographyPlan.model_validate(sample_plan())
        validate_plan_for_result(plan, "correct", ["correct"])

    def test_incorrect_accepts_negative_family(self) -> None:
        data = sample_plan(
            primitive="breathe",
            valence=-0.50,
            emotion_name="disappointment",
        )
        plan = ChoreographyPlan.model_validate(data)
        validate_plan_for_result(plan, "incorrect", ["incorrect"])

    def test_incorrect_rejects_positive_primitive(self) -> None:
        data = sample_plan(valence=-0.50, emotion_name="disappointment")
        plan = ChoreographyPlan.model_validate(data)
        with self.assertRaises(ValueError):
            validate_plan_for_result(plan, "incorrect", ["incorrect"])

    def test_result_rejects_wrong_emotion_name(self) -> None:
        data = sample_plan(emotion_name="disappointment")
        plan = ChoreographyPlan.model_validate(data)
        with self.assertRaises(ValueError):
            validate_plan_for_result(plan, "correct", ["correct"])

    def test_valence_must_have_strict_sign(self) -> None:
        data = sample_plan(valence=0.00)
        plan = ChoreographyPlan.model_validate(data)
        with self.assertRaises(ValueError):
            validate_plan_for_result(plan, "correct", ["correct"])

    def test_transition_type_rule(self) -> None:
        self.assertEqual(expected_transition_type(["correct"]), "continuation")
        self.assertEqual(
            expected_transition_type(["correct", "correct"]),
            "accumulation",
        )
        self.assertEqual(
            expected_transition_type(["correct", "incorrect"]),
            "reversal",
        )
        self.assertEqual(
            expected_transition_type(["correct", "incorrect", "correct"]),
            "fluctuation",
        )

    def test_transition_type_must_match_history(self) -> None:
        data = sample_plan(transition_type="continuation")
        plan = ChoreographyPlan.model_validate(data)
        with self.assertRaises(ValueError):
            validate_plan_for_result(
                plan,
                "correct",
                ["correct", "correct"],
            )

    def test_total_repeat_must_not_exceed_four(self) -> None:
        data = sample_plan()
        data["steps"] = [
            {
                "primitive": "rise",
                "amplitude_scale": 0.80,
                "speed_scale": 1.00,
                "repeat": 3,
            },
            {
                "primitive": "arm_pulse",
                "amplitude_scale": 0.80,
                "speed_scale": 1.00,
                "repeat": 2,
            },
        ]
        plan = ChoreographyPlan.model_validate(data)
        with self.assertRaises(ValueError):
            validate_plan_for_result(plan, "correct", ["correct"])

    def test_removed_fields_are_rejected(self) -> None:
        data = sample_plan()
        data["steps"][0]["hold_after_seconds"] = 0.20
        with self.assertRaises(ValidationError):
            ChoreographyPlan.model_validate(data)

    def test_prompt_parameter_bounds_are_enforced(self) -> None:
        data = sample_plan()
        data["steps"][0]["amplitude_scale"] = 0.59
        with self.assertRaises(ValidationError):
            ChoreographyPlan.model_validate(data)

    def test_steps_are_limited_to_three(self) -> None:
        data = sample_plan()
        data["steps"] = data["steps"] * 4
        with self.assertRaises(ValidationError):
            ChoreographyPlan.model_validate(data)

    def test_more_than_two_decimal_places_are_rejected(self) -> None:
        data = sample_plan()
        data["global_tempo"] = 1.001
        plan = ChoreographyPlan.model_validate(data)
        with self.assertRaises(ValueError):
            validate_plan_for_result(plan, "correct", ["correct"])

    def test_display_json_keeps_two_decimal_places(self) -> None:
        plan = ChoreographyPlan.model_validate(sample_plan())
        rendered = format_plan_json(plan)
        parsed = json.loads(rendered)
        self.assertEqual(parsed["emotion_state"]["valence"], 0.50)
        self.assertIn('"valence": 0.50', rendered)
        self.assertIn('"global_tempo": 1.00', rendered)


if __name__ == "__main__":
    unittest.main()
